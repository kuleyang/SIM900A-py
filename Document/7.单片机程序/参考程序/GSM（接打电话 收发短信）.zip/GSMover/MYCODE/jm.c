#include"stm32f10x.h"
#include"uart.h"
#include"nvic.h"
#include"w25x.h"
#include"lcd.h"
#include"gpio.h"
#include"jm.h"
#include"tim2.h"
#include"clock.h"
		  
u32 wei=0;
u8 wei0;
u32 bohao[20];
u32 duanxin[50];
u8 xx=1;
extern u8 shu;
extern u8 zt1;
extern u16 jieshou[100];
extern u16 ldhaoma[12];
extern u16 usarnum;
extern u8 wei1;
extern uc16 ring[4];
extern uc16 ncarrier[10];
extern uc16 errora[5];
extern uc16 ok[2];
extern uc16 cmti[6];
extern u32 time;

u8 zhuangtai(void)		 //��ѯGSMģ�鷵��״̬
{
    
	  {
	  	wei1=0;
    	if((jieshou[0]==ring[0])&&(jieshou[2]==ring[2]))
    	{
			return 1;
	   	}	
		if((jieshou[0]==ncarrier[0])&&(jieshou[1]==ncarrier[1])&&(jieshou[9]==ncarrier[9]))
		{
			return 2;	
		}
		if((jieshou[0]==errora[0])&&(jieshou[4]==errora[4]))
		{
			return 3;
		}
		if((jieshou[0]==ok[0])&&(jieshou[1]==ok[1]))
		{
			return 4;
		}
		if((jieshou[0]==cmti[0])&&(jieshou[1]==cmti[1])&&(jieshou[5]==cmti[5]))
		{
			return 5;
		}
      }
	return 0;	
}

void laidianxs(void)		//������ʾ
{
	u8 i;
	if((jieshou[0]==0x2b)&&(jieshou[17]==0x22))
	{
	 	for(i=0;i<12;i++)
		{
			switch(jieshou[18+i])
			{
				case 0x30 : LCD_ShowString((i*8+16),58,"0"); break;
				case 0x31 : LCD_ShowString((i*8+16),58,"1"); break;
				case 0x32 :	LCD_ShowString((i*8+16),58,"2"); break;
				case 0x33 : LCD_ShowString((i*8+16),58,"3"); break;
				case 0x34 : LCD_ShowString((i*8+16),58,"4"); break;
				case 0x35 : LCD_ShowString((i*8+16),58,"5"); break;
				case 0x36 : LCD_ShowString((i*8+16),58,"6"); break;
				case 0x37 : LCD_ShowString((i*8+16),58,"7"); break;
				case 0x38 : LCD_ShowString((i*8+16),58,"8"); break;
				case 0x39 : LCD_ShowString((i*8+16),58,"9"); break;
			}	
		}
	}	
}

void jiemian_init(void)		 //һ������
{
	LCD_Draw_window(0,0,128,160,WHITE);
	Chinesestr(8,16,"�ھŵ�Ƭ����̳",BLACK,WHITE);
	LCD_ShowString(16,32,"www.9mcu.com");
	Chinesestr(8,80,"��绰�밴  ��",BLACK,WHITE);
	LCD_ShowString(88,80," *");
	Chinesestr(8,100,"�������밴  ��",BLACK,WHITE);
	LCD_ShowString(88,100," #");
}

void jiemian_tonghua(void)		 //��绰����
{
	LCD_Draw_window(8,16,120,100,WHITE);
	Chinesestr(40,30,"�벦��",BLACK,WHITE);
	Chinesestr(8,100,"��  ������",BLACK,WHITE);
	LCD_ShowString(24,100," A");
	Chinesestr(8,120,"��  ��ɾ��",BLACK,WHITE);
	LCD_ShowString(24,120," B");
	Chinesestr(8,140,"��  ������",BLACK,WHITE);
	LCD_ShowString(24,140," D");
}

void tonghuaing(void)		 //�����н���
{
	LCD_Draw_window(0,0,128,48,WHITE);
	LCD_Draw_window(0,76,128,160,WHITE);
	Chinesestr(30,30,"���ڲ���",BLACK,WHITE);
	Chinesestr(8,140,"��  ���Ҷ�",BLACK,WHITE);
	LCD_ShowString(24,140," D");	
}

void tonghuaed(void)	  //ͨ���жϵĽ���
{
	LCD_Draw_window(0,30,128,50,WHITE);	
	Chinesestr(30,90,"ͨ�����ܾ�",BLACK,WHITE);
	Chinesestr(40,110,"��Ҷ�",BLACK,WHITE);	
}

void tonghuaed1(void)
{
	LCD_Draw_window(0,30,128,50,WHITE);	
	Chinesestr(30,90,"�Է��ѹһ�",BLACK,WHITE);	
}

void laidian(void)		   //������Ľ���
{
	LCD_Draw_window(8,16,120,120,WHITE);
	Chinesestr(40,30,"������",BLACK,WHITE);
	Chinesestr(8,100,"��  ������",BLACK,WHITE);
	LCD_ShowString(24,100," A");
	Chinesestr(8,120,"��  ���Ҷ�",BLACK,WHITE);
	LCD_ShowString(24,120," D");	
}

void duanxin_jiemian(void)		   //�����Ž���֮�༭����
{
	LCD_Draw_window(0,0,128,160,WHITE);
	Chinesestr(20,30,"��༭����",BLACK,WHITE);
	Chinesestr(8,100,"��  ��ȷ��",BLACK,WHITE);
	LCD_ShowString(24,100," A");
	Chinesestr(8,120,"��  ��ɾ��",BLACK,WHITE);
	LCD_ShowString(24,120," B");
	Chinesestr(8,140,"��  ������",BLACK,WHITE);
	LCD_ShowString(24,140," D");	
}

void saomiao_tonghua(void)		   //���ŵİ���ɨ��
{
	u8 t=0;
	u8 i;
	u8 k=0;
	wei=0;
	xx=1;
	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			//����1	�����ֵ
			{
			case 1:bohao[wei]=0x31;LCD_ShowString((wei*8+16),58,"1");wei++;break;
			case 2:bohao[wei]=0x32;LCD_ShowString((wei*8+16),58,"2");wei++;break;
			case 3:bohao[wei]=0x33;LCD_ShowString((wei*8+16),58,"3");wei++;break;
			case 5:bohao[wei]=0x34;LCD_ShowString((wei*8+16),58,"4");wei++;break;
			case 6:bohao[wei]=0x35;LCD_ShowString((wei*8+16),58,"5");wei++;break;
			case 7:bohao[wei]=0x36;LCD_ShowString((wei*8+16),58,"6");wei++;break;
			case 9:bohao[wei]=0x37;LCD_ShowString((wei*8+16),58,"7");wei++;break;
			case 10:bohao[wei]=0x38;LCD_ShowString((wei*8+16),58,"8");wei++;break;
			case 11:bohao[wei]=0x39;LCD_ShowString((wei*8+16),58,"9");wei++;break;
			case 14:bohao[wei]=0x30;LCD_ShowString((wei*8+16),58,"0");wei++;break;
			case 4:USART1_Puts("ATD ");
				   for(i=0;i<wei;i++)
				   {
				   	  USART1_Putc(bohao[i]);
				   }
				   USART1_Puts(";\r");
				   tonghuaing();
				   while(xx)
				   {
				   	  k=zhuangtai();
					   if(k)
					   {
					   	   switch(k)
						   {
						   	   case 2:tonghuaed();wei1=0;delay_ms(3000);jiemian_init();
			  						for(i=0;i<40;i++)
									{
										jieshou[i]=0;
									}xx=0; break;
							   case 4:LCD_Draw_window(0,0,128,160,WHITE);
					  				  Chinesestr(40,30,"�ѽ�ͨ",BLACK,WHITE);
									  Chinesestr(30,50,"����ͨ��",BLACK,WHITE);
									  Chinesestr(8,130,"��  ���Ҷ�",BLACK,WHITE);
									  LCD_ShowString(24,130," D");
									  saomiao_tonghuaing(); break;
						   }
					   }
					   t=KEY_Check();		//�������ɨ��
						if(t)
						{
							switch(t)			//����1	�����ֵ
							{				
								case 16:USART1_Puts("ATH\r");jiemian_init();xx=0;wei=0;
										for(i=0;i<40;i++)
										{
											bohao[i]=0;
											jieshou[i]=0;
										}
									break;
							}
						}
					   	
				   }
				   xx=0;
				   break;
			case 8:wei--;LCD_Draw_window((wei*8+16),58,(wei*8+24),74,WHITE);break;
			case 16:jiemian_init();xx=0;wei=0;
					for(i=0;i<20;i++)
					{
						bohao[i]=0;
					}
					break;
			}						   
		}
	}		
}

void saomiao_tonghuaing(void)		 //ͨ���еİ���ɨ��
{
	u8 t=0;
	u8 k=0;
	u8 i;
	xx=1;
	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			//����1	�����ֵ
			{				
				case 16:USART1_Puts("ATH\r");jiemian_init();xx=0;wei=0;
					for(i=0;i<40;i++)
					{
						bohao[i]=0;
						jieshou[i]=0;
					}
					break;
			}
		}
		k=zhuangtai();
		if(k)
		{
		   switch(k)
		   {
		   	  case 1:break;
			  case 2:tonghuaed();xx=0;wei1=0;delay_ms(3000);jiemian_init();
			  		for(i=0;i<40;i++)
					{
						jieshou[i]=0;
					}
					break;
			  case 3: tonghuaed1(); xx=0;wei1=0;delay_ms(3000);jiemian_init();
			  		for(i=0;i<40;i++)
					{
						jieshou[i]=0;
					}
					break;
		   }	
		}
		if(zt1)
		{
			STOP_TIME;
			zt1=0;
			wei=0;
			for(i=0;i<40;i++)
			{
				jieshou[i]=0;
			}
			ling_0;
			xx=0;
			jiemian_init();
		}				
	}	
}

void laidian_saomiao(void)				//���绰ʱ�İ���ɨ��
{
	u8 t=0;	
	u8 k=0;
	u8 i;
	xx=1;	
	START_TIME;
	USART1_Puts("AT+CLCC\r");
	while(time<300)
	{
	k=zhuangtai();
	laidianxs();
	}	
	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			
			{
				case 4:USART1_Puts("ATA\r");
					   LCD_Draw_window(0,0,128,160,WHITE);
					   Chinesestr(40,30,"�ѽ�ͨ",BLACK,WHITE);
					   Chinesestr(30,50,"����ͨ��",BLACK,WHITE);
					   Chinesestr(8,130,"��  ���Ҷ�",BLACK,WHITE);
					   LCD_ShowString(24,130," D");
					   ling_0;					   
					   saomiao_tonghuaing();
					   STOP_TIME;
					   xx=0;	break;
				case 16:USART1_Puts("ATH\r");STOP_TIME;jiemian_init();xx=0;wei=0;
						for(i=0;i<40;i++)
						{
							jieshou[i]=0;
						}
						ling_0;
						break;
			}
		}
		k=zhuangtai();
		if(k)
		{
		   switch(k)
		   {
		   	  case 1:time=0;
			 		 break;
			  case 2:break;
		   }
		   for(i=0;i<40;i++)
			{
				jieshou[i]=0;
			}
			wei1=0;
		}		
		if(zt1)
		{
			STOP_TIME;
			zt1=0;
			wei=0;
			for(i=0;i<40;i++)
			{
				jieshou[i]=0;
			}
			ling_0;
			xx=0;
			jiemian_init();
		}		  
	}
}

void saomiao_duanxin(void)			 //������ʱ�İ���ɨ��1
{
	u8 t=0;
	u8 i;
	wei=0;
	xx=1;

	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			//����1	�����ֵ
			{
			case 1:duanxin[wei]=0x31;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"1");wei++;break;
			case 2:duanxin[wei]=0x32;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"2");wei++;break;
			case 3:duanxin[wei]=0x33;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"3");wei++;break;
			case 5:duanxin[wei]=0x34;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"4");wei++;break;
			case 6:duanxin[wei]=0x35;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"5");wei++;break;
			case 7:duanxin[wei]=0x36;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"6");wei++;break;
			case 9:duanxin[wei]=0x37;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"7");wei++;break;
			case 10:duanxin[wei]=0x38;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"8");wei++;break;
			case 11:duanxin[wei]=0x39;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"9");wei++;break;
			case 14:duanxin[wei]=0x30;LCD_ShowString(((wei%14)*8+8),((wei/14)*16+50),"0");wei++;break;
			case 4:	wei0=wei;
					saomiao_duanxin1();
				   break;
			case 8:wei--;LCD_Draw_window((wei*8+8),50,(wei*8+16),66,WHITE);break;
			case 16:jiemian_init();xx=0;wei=0;
					for(i=0;i<40;i++)
					{
						duanxin[i]=0;
					}
					break;
			}						   
		}
	}		
}

void saomiao_duanxin1(void)		   //������ʱ�İ���ɨ��2
{
	u8 t=0;
	u8 i;
	u8 k=0;
	LCD_Draw_window(0,0,128,99,WHITE);
	Chinesestr(40,20,"������",BLACK,WHITE);
	Chinesestr(24,36,"Ŀ���ֻ���",BLACK,WHITE);
	wei=0;
	xx=1;
	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			//����1	�����ֵ
			{
			case 1:bohao[wei]=0x31;LCD_ShowString((wei*8+16),58,"1");wei++;break;
			case 2:bohao[wei]=0x32;LCD_ShowString((wei*8+16),58,"2");wei++;break;
			case 3:bohao[wei]=0x33;LCD_ShowString((wei*8+16),58,"3");wei++;break;
			case 5:bohao[wei]=0x34;LCD_ShowString((wei*8+16),58,"4");wei++;break;
			case 6:bohao[wei]=0x35;LCD_ShowString((wei*8+16),58,"5");wei++;break;
			case 7:bohao[wei]=0x36;LCD_ShowString((wei*8+16),58,"6");wei++;break;
			case 9:bohao[wei]=0x37;LCD_ShowString((wei*8+16),58,"7");wei++;break;
			case 10:bohao[wei]=0x38;LCD_ShowString((wei*8+16),58,"8");wei++;break;
			case 11:bohao[wei]=0x39;LCD_ShowString((wei*8+16),58,"9");wei++;break;
			case 14:bohao[wei]=0x30;LCD_ShowString((wei*8+16),58,"0");wei++;break;
			case 4:USART1_Puts("AT+CMGS=");
				   for(i=0;i<wei;i++)
				   {
				   	  USART1_Putc(bohao[i]);
				   }
				   USART1_Puts("\r");
				   delay_ms(500);
				   for(i=0;i<wei0;i++)
				   {
				   	  USART1_Putc(duanxin[i]);
				   }
				   USART1_Putc(0x1a);
				   USART1_Puts("\r");
				   while(xx)
				   {
				   	   k=zhuangtai();
					   if(k)
					   {
					   	   switch(k)
						   {
						   	   case 3:Chinesestr(8,80,"���ŷ���ʧ��",BLACK,WHITE);delay_ms(2000);xx=0; break;
							   case 4:Chinesestr(8,80,"���ŷ��ͳɹ�",BLACK,WHITE);delay_ms(2000);xx=0; break;
						   }
					   }	
				   }
				   break;
			case 8:wei--;LCD_Draw_window((wei*8+16),58,(wei*8+24),74,WHITE);break;
			case 16:jiemian_init();xx=0;wei=0;
					for(i=0;i<40;i++)
					{
						bohao[i]=0;
						duanxin[i]=0;
					}
					break;
			}						   
		}
	}
	wei=0;
	for(i=0;i<40;i++)
	{
		jieshou[i]=0;
	}
	jiemian_init();	
}

void xianshiduanxin(void)		   //������ʾ����
{
	u8 a,b,h,rq,xx;
	b=0;
	LCD_Draw_window(0,0,128,160,WHITE);
	Chinesestr(40,0,"������",BLACK,WHITE);
	for(a=0;a<100;a++)
	{
		if(jieshou[a]==0x22)
		{
			b++;
			switch(b)
			{
				case 3:  h=a+1;break;
				case 5:  rq=a+1;break;
				case 6:	 xx=a+3;break;
			}	
		}	
	}
	for(a=h;a<(rq-4);a++)
	{
		switch(jieshou[a])
		{
			case 0x2b: LCD_ShowString(((a-h)*8+8),20,"+");break;
			case 0x30: LCD_ShowString(((a-h)*8+8),20,"0");break;
			case 0x31: LCD_ShowString(((a-h)*8+8),20,"1");break;
			case 0x32: LCD_ShowString(((a-h)*8+8),20,"2");break;
			case 0x33: LCD_ShowString(((a-h)*8+8),20,"3");break;
			case 0x34: LCD_ShowString(((a-h)*8+8),20,"4");break;
			case 0x35: LCD_ShowString(((a-h)*8+8),20,"5");break;
			case 0x36: LCD_ShowString(((a-h)*8+8),20,"6");break;
			case 0x37: LCD_ShowString(((a-h)*8+8),20,"7");break;
			case 0x38: LCD_ShowString(((a-h)*8+8),20,"8");break;
			case 0x39: LCD_ShowString(((a-h)*8+8),20,"9");break;
		}
	}
	for(a=rq;a<(xx-9);a++)
	{
		switch(jieshou[a])
		{
			case 0x2f: LCD_ShowString(((a-rq)*8+8),40,"/");break;
			case 0x30: LCD_ShowString(((a-rq)*8+8),40,"0");break;
			case 0x31: LCD_ShowString(((a-rq)*8+8),40,"1");break;
			case 0x32: LCD_ShowString(((a-rq)*8+8),40,"2");break;
			case 0x33: LCD_ShowString(((a-rq)*8+8),40,"3");break;
			case 0x34: LCD_ShowString(((a-rq)*8+8),40,"4");break;
			case 0x35: LCD_ShowString(((a-rq)*8+8),40,"5");break;
			case 0x36: LCD_ShowString(((a-rq)*8+8),40,"6");break;
			case 0x37: LCD_ShowString(((a-rq)*8+8),40,"7");break;
			case 0x38: LCD_ShowString(((a-rq)*8+8),40,"8");break;
			case 0x39: LCD_ShowString(((a-rq)*8+8),40,"9");break;
			case 0x2c: LCD_ShowString(((a-rq)*8+8),40,",");break;
			case 0x3a: LCD_ShowString(((a-rq)*8+8),40,":");break;
		}
	}
	Chinesestr(0,60,"����",BLACK,WHITE);
	LCD_ShowString(32,60,":");
	for(a=xx;a<(wei1-2);a++)
	{
		switch(jieshou[a])
		{
			case 0x30: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"0");break;
			case 0x31: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"1");break;
			case 0x32: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"2");break;
			case 0x33: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"3");break;
			case 0x34: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"4");break;
			case 0x35: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"5");break;
			case 0x36: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"6");break;
			case 0x37: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"7");break;
			case 0x38: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"8");break;
			case 0x39: LCD_ShowString((((a-xx)%14)*8+8),(77+(((a-xx)/14)*16)),"9");break;	
		}
	}
	Chinesestr(24,120,"��  ��ɾ��",BLACK,WHITE);
	Chinesestr(24,140,"���Ų��˳�",BLACK,WHITE);
	LCD_ShowString(40,120," D");	
}

void shanduanxin(void)		 //�鿴���ŵİ���ɨ�裨ɾ�����Ų��˳���
{
	u8 t=0;
	u8 i;
	wei=0;
	xx=1;
	while(xx)
	{
		t=KEY_Check();		//�������ɨ��
		if(t)
		{
			switch(t)			//����1	�����ֵ
			{				
				case 16:USART1_Puts("AT+CMGD=");
						USART1_Putc(shu);
						USART1_Puts("\r");	
				    	jiemian_init();xx=0;wei=0;
						for(i=0;i<100;i++)
						{
							jieshou[i]=0;
						}
						break;
			}	   	
		}
	}		
}
