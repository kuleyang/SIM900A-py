#ifndef __LCD_H
#define __LCD_H
	
#include "stm32f10x.h"	 
#include "stdlib.h"

#define LCD_CS_1 	 GPIO_SetBits(GPIOB,GPIO_Pin_12)
#define LCD_CS_0     GPIO_ResetBits(GPIOB,GPIO_Pin_12)   
#define LCD_RES_1    GPIO_SetBits(GPIOB,GPIO_Pin_11)
#define LCD_RES_0    GPIO_ResetBits(GPIOB,GPIO_Pin_11)   
#define LCD_DC_1     GPIO_SetBits(GPIOB,GPIO_Pin_10)
#define LCD_DC_0     GPIO_ResetBits(GPIOB,GPIO_Pin_10)   
#define LCD_WRB_1    GPIO_SetBits(GPIOB,GPIO_Pin_9)
#define LCD_WRB_0    GPIO_ResetBits(GPIOB,GPIO_Pin_9)   
#define LCD_RD_1     GPIO_SetBits(GPIOB,GPIO_Pin_8)
#define LCD_RD_0     GPIO_ResetBits(GPIOB,GPIO_Pin_8)
   
void LCD_Write_REG(u8 a);
void LCD_Write_DATA(u8 b);
void Init_LCD(void);

void LCD_SetPoint(u16 x,u16 y);
void LCD_DrawPoint(u16 x,u16 y,u16 color);

void LCD_Draw_window(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color);

void LCD_ShowChar(u16 x,u16 y,u8 num);
void LCD_ShowString(u16 x,u16 y,const u8 *p);

void LCD_Color(u16 color);

void Chinese(u16 Xpos,u16 Ypos,u8 *hz,u16 Color,u16 bkColor);
void Chinesestr(u16 Xpos, u16 Ypos, u8 *str,u16 Color, u16 bkColor);

#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE         	 0x001F  
#define BRED             0XF81F
#define GRED 			 0XFFE0
#define GBLUE			 0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#endif
