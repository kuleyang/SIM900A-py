#ifndef __CLOCK_H
#define __CLOCK_H
#include "stm32f10x.h"

void delay_10us(void);
void delay_ms(u32 i);

#endif
