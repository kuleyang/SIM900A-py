#include"clock.h"

void delay_10us(void)			 //10us�ľ�ȷ��ʱ
{
	u8 x,y;
	for(x=0;x<12;x++)
		for(y=0;y<6;y++);	
}

void delay_ms(u32 i)   			   //iX1ms�ľ�ȷ��ʱ
{
	u32 t;
	i=i*100;
	for(t=0;t<i;t++)
		delay_10us();
}
