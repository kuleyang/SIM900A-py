
#include "GPIO.h"
#include"clock.h"


void GPIO_Config(void)
{	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOA,ENABLE);
	/* ������ߵ�ƽ */
	/* PC0 PC1 PC2 PC3 �������*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
	/*����*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
	/* ������*/
	/* PC4 PC5 PC6 PC7 ��������*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IPU; 
    GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC,GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);
}

u8 KEY_Check(void)
{	  static u8 key;
	  GPIO_ResetBits(GPIOC,GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3); //�����0
	  if((L1&L2&L3&L4)==0)													   //�ж���0�����а������£��ж���1���ް������¡�
	  {	  
	  	  GPIO_SetBits(GPIOC,GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3);	//��һ����0��������1��Ҫע������Ҫ����һ����1.
		  H1_0;		  
		  if(L1==0)   //����һ���Ƿ�Ϊ0
		  {
		  	delay_ms(10);//����һ��Ϊ0����ʱ����
			if(L1==0)	 //����һ��Ϊ0
			{	
				if(key==1)	//����1�Ѿ�������
				{	delay_ms(300); //��ʱ300ms���������¼�⡣
					key=0;		   		
				}else
				{
				    H1_1;		   //��һ�б���1
					key=1;		   //����1������
					return 1;	   //���ؼ�ֵ
				} 								
			}	
		  }else if(L2==0)
		  {
		  	delay_ms(10);
			if(L2==0)
			{	
				if(key==2)
				{	delay_ms(300);
					key=0;					
				}else
				{
				 H1_1;
				 key=2;
				 return 2;
				}				
			}
		  }else if(L3==0)
		  {
		  	delay_ms(10);
			if(L3==0)
			{	
				if(key==3)
				{	delay_ms(300);
					key=0;					
				}else
				{
				 H1_1;
				 key=3;
				 return 3;
				}				
			}
		  }else if(L4==0)
		  {
		  	delay_ms(10);
			if(L4==0)
			{	
				if(key==4)
				{	delay_ms(300);
					key=0;					
				}else
				{
				 H1_1;
				 key=4;
				 return 4;
				}				
			}
		  }
		 H1_1;

		 H2_0;
		  if(L1==0)
		  {
		  	delay_ms(10);
			if(L1==0)
			{	
				if(key==5)
				{	delay_ms(300);
					key=0;
				}else
				{
				 H2_1;
				key=5;
				return 5;
				}
			}
	
		  }else if(L2==0)
		  {
		  	delay_ms(10);
			if(L2==0)
			{	
				if(key==6)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H2_1;
				 key=6;
				 return 6;
				}
				
			}
		  }else if(L3==0)
		  {
		  	delay_ms(10);
			if(L3==0)
			{	
				if(key==7)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H2_1;
				 key=7;
				 return 7;
				}
				
			}
		  }else if(L4==0)
		  {
		  	delay_ms(10);
			if(L4==0)
			{	
				if(key==8)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H2_1;
				 key=8;
				 return 8;
				}
				
			}
		  }
		  H2_1;
		  H3_0;
		   if(L1==0)
		  {
		  	delay_ms(10);
			if(L1==0)
			{	
				if(key==9)
				{	delay_ms(300);
					key=0;
				}else
				{
				 H3_1;
				key=9;
				return 9;
				}
			}
	
		  }else if(L2==0)
		  {
		  	delay_ms(10);
			if(L2==0)
			{	
				if(key==10)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H3_1;
				 key=10;
				 return 10;
				}
				
			}
		  }else if(L3==0)
		  {
		  	delay_ms(10);
			if(L3==0)
			{	
				if(key==11)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H3_1;
				 key=11;
				 return 11;
				}
				
			}
		  }else if(L4==0)
		  {
		  	delay_ms(10);
			if(L4==0)
			{	
				if(key==12)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H3_1;
				 key=12;
				 return 12;
				}
				
			}
		  }
		  H3_1;
		  H4_0;
		   if(L1==0)
		  {
		  	delay_ms(10);
			if(L1==0)
			{	
				if(key==13)
				{	delay_ms(300);
					key=0;
				}else
				{
				 H4_1;
				key=13;
				return 13;
				}
			}
	
		  }else if(L2==0)
		  {
		  	delay_ms(10);
			if(L2==0)
			{	
				if(key==14)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H4_1;
				 key=14;
				 return 14;
				}
				
			}
		  }else if(L3==0)
		  {
		  	delay_ms(10);
			if(L3==0)
			{	
				if(key==15)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H4_1;
				 key=15;
				 return 15;
				}
				
			}
		  }else if(L4==0)
		  {
		  	delay_ms(10);
			if(L4==0)
			{	
				if(key==16)
				{
					delay_ms(300);
					key=0;
				}else
				{
				 H4_1;
				 key=16;
				 return 16;
				}
				
			}
		  }
		  H4_1;
	 }
 return 0;
}

