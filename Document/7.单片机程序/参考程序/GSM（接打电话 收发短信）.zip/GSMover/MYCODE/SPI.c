/**
  ******************************************************************************
  * �ļ���    SPI.c 
  * ����      ��ʼ��SPI
  * ��汾    V3.5.0
  * ����      2012-11-16
  * ʵ��ƽ̨  С���
  * Ӳ������  
  ******************************************************************************
  * By���ھŵ�Ƭ����̳ nibutaiguai
  ****************************************************************************** 
  */ 
#include "stm32f10x.h"
#include "SPI.h"
void SPI1_FLASH_Init(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  /*ʹ��GPIOA��SPI1ʱ��*/
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |RCC_APB2Periph_SPI1, ENABLE);
  /*����GPIOA��PA4���������PA5��PA6��PA7����������������Ƶ��50MHz*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_SetBits(GPIOA,GPIO_Pin_4);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  /*����SPI*/
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//ȫ˫��
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;						//��ģʽ
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;					//8bit
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;						//ģʽ3
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;						//
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;//2��Ƶ
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;				//��λ��ǰ
  SPI_InitStructure.SPI_CRCPolynomial = 7;							
  SPI_Init(SPI1, &SPI_InitStructure);

  SPI_Cmd(SPI1, ENABLE);
}
//�����ֽ�
u8 SPI1_ReadByte(void)
{
	return (SPI1_WriteByte(0xFF));
}
//�����ֽ�
u8 SPI1_WriteByte(u8 byte)	
{
	while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
	SPI_I2S_SendData(SPI1, byte);
	while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
	return SPI_I2S_ReceiveData(SPI1);
}
