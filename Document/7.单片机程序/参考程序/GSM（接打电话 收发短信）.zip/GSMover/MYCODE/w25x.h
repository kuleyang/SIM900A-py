#ifndef __W25X_H
#define __W25X_H			 
#include "stm32f10x.h"
/*----------------W25X16����--------------------*/
#define W25X16_CHIPID		  0xEF3015
#define W25X_PAGE_SIZE        256       //1ҳ256���ֽ�
#define W25X_PERPAGE_SIZE     256	    //ÿҳ256���ֽ�
#define	W25X_SECTOR_SIZE	  4096	    //1����16*256���ֽ�
#define FLASH_BLOCK_SIZE	  65536	    //1��16*16*256���ֽ�

/*----------------W25X16����--------------------*/
#define W25X_WriteEnable			0x06
#define W25X_WriteDisable			0x04
#define W25X_ReadStatusReg			0x05
#define W25X_WriteStatusReg			0x01
#define W25X_ReadData				0x03
#define W25X_FastReadData			0x0B
#define W25X_FastReadDual			0x3B
#define W25X_PageProgram			0x02
#define W25X_BlockErase				0xD8
#define W25X_SectorErase			0x20
#define W25X_ChipErase				0xC7
#define W25X_SetPowerDown			0xB9
#define W25X_SetReleasePowerDown	0xAB
#define W25X_DeviceID				0xAB
#define W25X_ManufactDeviceID		0x90
#define W25X_JedecDeviceID			0x9F

/*----------------CSƬѡ�ź�--------------------*/
#define FLASH_CS_0			GPIO_ResetBits(GPIOA,GPIO_Pin_4)
#define FLASH_CS_1			GPIO_SetBits(GPIOA,GPIO_Pin_4)

/*-----------------Ӧ�ú���---------------------*/
void W25X_FLASH_Init(void);
void W25X_Write_Enable(void);
void W25X_Write_Disable(void);

u8 W25X_Read_StatusReg(void);
void W25X_Write_StatusReg(u8 reg);

void W25X_Wait_Busy(void);
u32 W25X_JEDECID(void);

void W25X_Erase_Sector(u32 SectorAddr);
void W25X_Erase_Block(u32 BlockAddr);
void W25X_Erase_Chip(void);

void W25X_Read_Bytes(u32 RAddr,u8* pBuffer,  u16 Num);
void W25X_Write_Bytes(u32 WAddr,u8* pBuffer, u16 Num);

void W25X_PowerDown(void);
void W25X_ReleasePowerDown(void);

#endif
