#ifndef __JM_H
#define __JM_H

#define ling_0 GPIO_SetBits(GPIOA,GPIO_Pin_0 )
#define ling_1 GPIO_ResetBits(GPIOA,GPIO_Pin_0 )

void jiemian_init(void);
void jiemian_tonghua(void);
void saomiao_tonghua(void);
void tonghuaing(void);
void saomiao_tonghuaing(void);
void laidian(void);
u8 zhuangtai(void);
void laidian_saomiao(void);
void tonghuaed(void);
void tonghuaed1(void);
void laidianxs(void);
void duanxin_jiemian(void);
void saomiao_duanxin(void);
void saomiao_duanxin1(void);
void xianshiduanxin(void);
void shanduanxin(void);


#endif
