#ifndef __SPI_H
#define __SPI_H			 
#include "stm32f10x.h"
/*-----------------Ӧ�ú���---------------------*/
void SPI1_FLASH_Init(void);

u8 SPI1_ReadByte(void);
u8 SPI1_WriteByte(u8 byte);

#endif

