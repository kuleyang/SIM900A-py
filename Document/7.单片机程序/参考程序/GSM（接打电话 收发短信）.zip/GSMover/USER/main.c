#include"stm32f10x.h"
#include"uart.h"
#include"nvic.h"
#include"w25x.h"
#include"lcd.h"
#include"jm.h"
#include"gpio.h"
#include"tim2.h"
#include"clock.h"

extern u16 usarnum;
extern u16 jieshou[100];
extern u8 wei1;
u8 shu;

int main(void)
{
	u8 t=0;
	u8 k=0;
	u8 i,x;
	u32 kkk;
	u8 kk=0;
	TIM2_NVIC_Configuration();
	TIM2_Configuration();
	GPIO_Config();
	ling_0;
	Init_LCD(); 
	/*��ʼ���ж�����*/
	NVIC_Config();
	/*uart���ڳ�ʼ��*/
	USART1_Config();
	USART1_Puts("AT&F\r");
	delay_ms(500);
	USART1_Puts("AT+CMGF=1\r");
	delay_ms(500);
    USART1_Puts("AT+CNMI=2,1\r");
	delay_ms(500);
	USART1_Puts("AT+CMGL=ALL\r");
	wei1=0;
	kkk=6000000;
	while(kkk--)
	{
		if(usarnum==0x4c)
		{
			wei1=0;
		}		
	}
	for(x=1;x<(jieshou[2]-0x2f);x++)    //ɾ�����ж���
	{
		USART1_Puts("AT+CMGD=");
		USART1_Putc(0x30+x);
		USART1_Puts("\r");
		delay_ms(200);	
	}

	W25X_FLASH_Init();
	W25X_ReleasePowerDown();
	jiemian_init();	
	while(1)
	{
		 t=KEY_Check();		//�������ɨ��
		 if(t)
		 {
			 switch(t)			//����1	�����ֵ
			 {
			 case 13:						   //��绰
			 		 jiemian_tonghua();
					 saomiao_tonghua();
					 break;
			 case 15:duanxin_jiemian();		   //������
			 		  saomiao_duanxin();
			         break;
			 case 16:if(kk)					//�鿴����
			 		 {
					 	 USART1_Puts("AT+CMGR=");
						 USART1_Putc(shu);
						 USART1_Puts("\r");
						 wei1=0;
						 delay_ms(300);
						 xianshiduanxin();
						 shanduanxin();
						 wei1=0;
						 kk=0;
					 }
			 		 break;
			 }						   
		 }
		 k=zhuangtai();	
		 if(k)
		{
		   switch(k)
		   {
		   	  case 1:ling_1;laidian();laidian_saomiao();wei1=0;break;		  //�������
			  case 5:Chinesestr(24,120,"�յ�����Ϣ",BLACK,WHITE);			  //������
			  		 Chinesestr(24,140,"�밴  �鿴",BLACK,WHITE);
					 LCD_ShowString(56,140," D"); kk=1;
					 shu=jieshou[12];
					 for(i=0;i<20;i++)
				  	 {
						jieshou[i]=0;
					 }
					 k=0;
			  		 break;
		   }	
		}	  				   
	}
}
